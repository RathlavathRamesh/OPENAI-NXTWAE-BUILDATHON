import { Button } from "@/components/ui/button";
import { AlertTriangle, Shield, MapPin, MessageSquare, Settings, BarChart3, Menu, Home } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

interface NavigationProps {
  currentPage: string;
  onPageChange: (page: string) => void;
}

export const Navigation = ({ currentPage, onPageChange }: NavigationProps) => {
  return (
    <nav className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-4 md:gap-8">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-6 w-6 md:h-8 md:w-8 text-primary" />
              <span className="text-lg md:text-xl font-bold text-foreground">Emergency Tracker</span>
            </div>
            
            <div className="hidden lg:flex items-center gap-6">
              <Button 
                variant={currentPage === 'dashboard' ? "default" : "ghost"} 
                className="gap-2"
                onClick={() => onPageChange('dashboard')}
              >
                <BarChart3 className="h-4 w-4" />
                Dashboard
              </Button>
              <Button 
                variant={currentPage === 'incidents' ? "default" : "ghost"} 
                className="gap-2"
                onClick={() => onPageChange('incidents')}
              >
                <MapPin className="h-4 w-4" />
                Incidents
              </Button>
              <Button 
                variant={currentPage === 'map' ? "default" : "ghost"} 
                className="gap-2"
                onClick={() => onPageChange('map')}
              >
                <Shield className="h-4 w-4" />
                Map View
              </Button>
              <Button 
                variant={currentPage === 'communications' ? "default" : "ghost"} 
                className="gap-2"
                onClick={() => onPageChange('communications')}
              >
                <MessageSquare className="h-4 w-4" />
                AI Assistant
              </Button>
            </div>
          </div>
          
          <div className="flex items-center gap-2 md:gap-4">
            {currentPage !== 'home' && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => onPageChange('home')}
                className="gap-2"
              >
                <Home className="h-4 w-4" />
                <span className="hidden sm:inline">Home</span>
              </Button>
            )}
            <Button 
              variant="emergency" 
              size="sm"
              onClick={() => onPageChange('report')}
              className="hidden sm:flex"
            >
              Report Emergency
            </Button>
            <ThemeToggle />
            <Button 
              variant="ghost" 
              size="sm"
              onClick={() => onPageChange('settings')}
              className="hidden md:flex"
            >
              <Settings className="h-4 w-4" />
            </Button>
            
            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="sm" className="lg:hidden">
                  <Menu className="h-5 w-5" />
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-64">
                <div className="flex flex-col gap-4 mt-8">
                  <Button 
                    variant={currentPage === 'dashboard' ? "default" : "ghost"} 
                    className="w-full justify-start gap-2"
                    onClick={() => onPageChange('dashboard')}
                  >
                    <BarChart3 className="h-4 w-4" />
                    Dashboard
                  </Button>
                  <Button 
                    variant={currentPage === 'incidents' ? "default" : "ghost"} 
                    className="w-full justify-start gap-2"
                    onClick={() => onPageChange('incidents')}
                  >
                    <MapPin className="h-4 w-4" />
                    Incidents
                  </Button>
                  <Button 
                    variant={currentPage === 'map' ? "default" : "ghost"} 
                    className="w-full justify-start gap-2"
                    onClick={() => onPageChange('map')}
                  >
                    <Shield className="h-4 w-4" />
                    Map View
                  </Button>
                  <Button 
                    variant={currentPage === 'communications' ? "default" : "ghost"} 
                    className="w-full justify-start gap-2"
                    onClick={() => onPageChange('communications')}
                  >
                    <MessageSquare className="h-4 w-4" />
                    Communications
                  </Button>
                  <Button 
                    variant="emergency" 
                    className="w-full justify-start gap-2"
                    onClick={() => onPageChange('report')}
                  >
                    <AlertTriangle className="h-4 w-4" />
                    Report Emergency
                  </Button>
                  <Button 
                    variant={currentPage === 'settings' ? "default" : "ghost"}
                    className="w-full justify-start gap-2"
                    onClick={() => onPageChange('settings')}
                  >
                    <Settings className="h-4 w-4" />
                    Settings
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </nav>
  );
};