import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  MessageSquare, 
  Phone, 
  Video, 
  Send, 
  Mic, 
  Image, 
  MapPin, 
  AlertTriangle,
  Users,
  Volume2,
  Paperclip,
  Search,
  Home
} from 'lucide-react';
import { dummyMessages } from '@/lib/dummyData';
import { Message } from '@/lib/types';

interface CommunicationsPageProps {
  onPageChange?: (page: string) => void;
}

export const CommunicationsPage = ({ onPageChange }: CommunicationsPageProps) => {
  const [messages, setMessages] = useState<Message[]>(dummyMessages);
  const [newMessage, setNewMessage] = useState<string>('');
  const [selectedChannel, setSelectedChannel] = useState<string>('all-units');
  const [isRecording, setIsRecording] = useState<boolean>(false);

  const channels = [
    { id: 'all-units', name: 'All Units', description: 'General emergency communications' },
    { id: 'fire-dept', name: 'Fire Department', description: 'Fire and rescue operations' },
    { id: 'medical', name: 'Medical Teams', description: 'Medical emergency response' },
    { id: 'police', name: 'Police Units', description: 'Police and security operations' },
    { id: 'command', name: 'Command Center', description: 'Command and coordination' },
    { id: 'citizens', name: 'Citizen Reports', description: 'Public emergency reports' },
  ];

  const emergencyContacts = [
    { name: 'Fire Chief Johnson', role: 'Fire Department', status: 'online', phone: '+1-555-FIRE-001' },
    { name: 'Dr. Sarah Chen', role: 'Medical Director', status: 'busy', phone: '+1-555-MED-001' },
    { name: 'Captain Rodriguez', role: 'Police Chief', status: 'online', phone: '+1-555-POLICE-001' },
    { name: 'Command Center', role: 'Operations', status: 'online', phone: '+1-555-COMMAND' },
    { name: 'Emergency Dispatch', role: 'Dispatch', status: 'online', phone: '+1-555-911-DISP' },
  ];

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const message: Message = {
        id: `MSG${Date.now()}`,
        from: 'Current User',
        to: selectedChannel,
        content: newMessage,
        type: 'text',
        timestamp: new Date(),
        isEmergency: newMessage.toLowerCase().includes('emergency') || newMessage.toLowerCase().includes('urgent')
      };
      setMessages([...messages, message]);
      setNewMessage('');
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatTime = (timestamp: Date) => {
    return timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return 'bg-success';
      case 'busy': return 'bg-warning';
      case 'offline': return 'bg-muted';
      default: return 'bg-muted';
    }
  };

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-3 mb-2">
            {onPageChange && (
              <Button variant="ghost" size="sm" onClick={() => onPageChange('home')} className="gap-2">
                <Home className="h-4 w-4" />
                <span className="hidden sm:inline">Back to Home</span>
              </Button>
            )}
            <h1 className="text-2xl md:text-3xl font-bold text-foreground">Emergency Communications</h1>
          </div>
          <p className="text-sm md:text-base text-muted-foreground">Real-time communication hub for emergency response</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" className="gap-2">
            <Phone className="h-4 w-4" />
            <span className="hidden sm:inline">Emergency Call</span>
          </Button>
          <Button variant="emergency" size="sm" className="gap-2">
            <AlertTriangle className="h-4 w-4" />
            <span className="hidden sm:inline">Alert All</span>
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 md:gap-6">
        {/* Channels & Contacts Sidebar */}
        <div className="space-y-4 lg:h-[calc(100vh-220px)] overflow-y-auto">
          <Card className="border-2">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <MessageSquare className="h-5 w-5 text-primary" />
                Channels
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-1">
              {channels.map((channel) => (
                <Button
                  key={channel.id}
                  variant={selectedChannel === channel.id ? "default" : "ghost"}
                  className="w-full justify-start h-auto p-3 transition-all hover:scale-[1.02]"
                  onClick={() => setSelectedChannel(channel.id)}
                >
                  <div className="text-left w-full">
                    <div className="font-semibold text-sm flex items-center justify-between">
                      {channel.name}
                      {selectedChannel === channel.id && (
                        <Badge variant="secondary" className="ml-2 text-xs">Active</Badge>
                      )}
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">{channel.description}</div>
                  </div>
                </Button>
              ))}
            </CardContent>
          </Card>

          <Card className="border-2">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-lg">
                <Users className="h-5 w-5 text-primary" />
                Emergency Contacts
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {emergencyContacts.map((contact, index) => (
                <div key={index} className="flex items-center gap-2 p-2 rounded-lg hover:bg-accent/50 transition-all hover:scale-[1.02] cursor-pointer border border-transparent hover:border-primary/20">
                  <div className="relative">
                    <Avatar className="h-10 w-10 border-2 border-primary/20">
                      <AvatarFallback className="text-xs font-semibold bg-gradient-to-br from-primary/20 to-primary/5">
                        {contact.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className={`absolute -bottom-0.5 -right-0.5 w-3.5 h-3.5 rounded-full border-2 border-card ${getStatusColor(contact.status)} shadow-sm`} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold text-sm truncate">{contact.name}</div>
                    <div className="text-xs text-muted-foreground flex items-center gap-1">
                      {contact.role}
                      <span className="text-[10px]">• {contact.status}</span>
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0 hover:bg-primary hover:text-primary-foreground transition-colors">
                      <Phone className="h-3.5 w-3.5" />
                    </Button>
                    <Button size="sm" variant="ghost" className="h-7 w-7 p-0 hover:bg-primary hover:text-primary-foreground transition-colors">
                      <Video className="h-3.5 w-3.5" />
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>

        {/* Main Chat Area */}
        <div className="lg:col-span-3">
          <Card className="lg:h-[calc(100vh-220px)] flex flex-col border-2 shadow-lg">
            <CardHeader className="flex-shrink-0 border-b bg-gradient-to-r from-primary/5 to-transparent">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <CardTitle className="flex items-center gap-2 text-lg">
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <MessageSquare className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <div className="font-bold">{channels.find(c => c.id === selectedChannel)?.name || 'Channel'}</div>
                    <Badge variant="secondary" className="text-xs mt-1">
                      {messages.filter(m => m.to === selectedChannel || m.from === selectedChannel).length} messages
                    </Badge>
                  </div>
                </CardTitle>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" className="gap-2 hover:bg-primary hover:text-primary-foreground transition-colors">
                    <Search className="h-3 w-3" />
                    <span className="hidden sm:inline">Search</span>
                  </Button>
                  <Button variant="outline" size="sm" className="gap-2 hover:bg-primary hover:text-primary-foreground transition-colors">
                    <Volume2 className="h-3 w-3" />
                    <span className="hidden sm:inline">Audio</span>
                  </Button>
                </div>
              </div>
            </CardHeader>

            {/* Messages */}
            <CardContent className="flex-1 overflow-y-auto space-y-4 p-4 bg-gradient-to-b from-background to-muted/20 min-h-[400px]">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex gap-3 ${
                    message.from === 'Current User' ? 'flex-row-reverse' : 'flex-row'
                  }`}
                >
                  <Avatar className="h-9 w-9 flex-shrink-0 border-2 border-primary/20 shadow-sm">
                    <AvatarFallback className="text-xs font-semibold bg-gradient-to-br from-primary/20 to-primary/5">
                      {message.from.split(' ').map(n => n[0]).join('')}
                    </AvatarFallback>
                  </Avatar>
                  <div className={`flex-1 max-w-[85%] md:max-w-[70%] ${message.from === 'Current User' ? 'text-right' : ''}`}>
                    <div className={`flex items-center gap-2 mb-1.5 ${message.from === 'Current User' ? 'justify-end' : ''}`}>
                      <span className="font-semibold text-sm">{message.from}</span>
                      <span className="text-xs text-muted-foreground">{formatTime(message.timestamp)}</span>
                      {message.isEmergency && (
                        <Badge variant="destructive" className="text-xs animate-pulse">
                          <AlertTriangle className="h-3 w-3 mr-1" />
                          URGENT
                        </Badge>
                      )}
                    </div>
                    <div className={`rounded-2xl p-3.5 shadow-md transition-all hover:scale-[1.02] ${
                      message.from === 'Current User' 
                        ? 'bg-gradient-to-br from-primary to-primary/80 text-primary-foreground ml-auto' 
                        : message.isEmergency
                          ? 'bg-gradient-to-br from-destructive/20 to-destructive/10 border-2 border-destructive/30'
                          : 'bg-gradient-to-br from-muted to-muted/50'
                    }`}>
                      <p className="text-sm leading-relaxed">{message.content}</p>
                    </div>
                  </div>
                </div>
              ))}
            </CardContent>

            {/* Message Input */}
            <div className="flex-shrink-0 p-4 border-t bg-gradient-to-r from-muted/30 to-transparent">
              <div className="flex flex-col md:flex-row gap-3">
                <div className="flex-1 space-y-2">
                  <Textarea
                    placeholder="Type your message... (Press Enter to send, Shift+Enter for new line)"
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={handleKeyPress}
                    className="min-h-[70px] resize-none border-2 focus:border-primary transition-colors"
                  />
                  <div className="flex flex-wrap items-center gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      className={`gap-2 transition-all ${isRecording ? 'bg-destructive text-destructive-foreground animate-pulse' : 'hover:bg-primary hover:text-primary-foreground'}`}
                      onClick={() => setIsRecording(!isRecording)}
                    >
                      <Mic className="h-3.5 w-3.5" />
                      {isRecording ? 'Recording...' : 'Voice'}
                    </Button>
                    <Button variant="outline" size="sm" className="gap-2 hover:bg-primary hover:text-primary-foreground transition-colors">
                      <Image className="h-3.5 w-3.5" />
                      <span className="hidden sm:inline">Image</span>
                    </Button>
                    <Button variant="outline" size="sm" className="gap-2 hover:bg-primary hover:text-primary-foreground transition-colors">
                      <MapPin className="h-3.5 w-3.5" />
                      <span className="hidden sm:inline">Location</span>
                    </Button>
                    <Button variant="outline" size="sm" className="gap-2 hover:bg-primary hover:text-primary-foreground transition-colors">
                      <Paperclip className="h-3.5 w-3.5" />
                      <span className="hidden sm:inline">File</span>
                    </Button>
                  </div>
                </div>
                <div className="flex md:flex-col gap-2">
                  <Button
                    onClick={handleSendMessage}
                    disabled={!newMessage.trim()}
                    className="flex-1 md:flex-initial md:h-[70px] md:px-6 gap-2 shadow-lg hover:shadow-xl transition-all"
                  >
                    <Send className="h-4 w-4" />
                    <span className="md:hidden">Send</span>
                  </Button>
                  <Button variant="emergency" size="sm" className="gap-2 shadow-md hover:shadow-lg transition-all">
                    <AlertTriangle className="h-3.5 w-3.5" />
                    URGENT
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
        <Button variant="emergency" className="gap-2">
          <AlertTriangle className="h-4 w-4" />
          Mass Alert
        </Button>
        <Button variant="secondary" className="gap-2">
          <Phone className="h-4 w-4" />
          Conference Call
        </Button>
        <Button variant="outline" className="gap-2">
          <Video className="h-4 w-4" />
          Video Meeting
        </Button>
        <Button variant="outline" className="gap-2">
          <MessageSquare className="h-4 w-4" />
          Broadcast SMS
        </Button>
        <Button variant="outline" className="gap-2">
          <Volume2 className="h-4 w-4" />
          Public Address
        </Button>
      </div>
    </div>
  );
};